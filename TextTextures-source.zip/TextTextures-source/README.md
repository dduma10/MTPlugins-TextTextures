# Text Textures 0.3.1: source

The source for the Text Textures plugin (MTPlugins / RadiantPlugins host, BO3 Mod Tools).

- `TextTextures/` is the plugin: pane, text rendering, 3D text, glow. Its README covers use.
- `common/` is shared code: GDT writer, PNG encoder, xmodel export, map text editing, platform helpers.
- `sdk/` is the MTPlugins plugin SDK (`modtools_plugin.h`, `modtools_plugin.hpp`).

## Build

- **Visual Studio:** open `TextTextures.sln` and build Release | x64. The output is `TextTextures.dll`.
- **CMake (MSVC or MinGW):** `cmake -S . -B build -A x64`, then `cmake --build build --config Release`.
- **MinGW from Linux:**
  ```
  x86_64-w64-mingw32-g++ -std=c++17 -O2 -Isdk -Icommon -ITextTextures -DWIN32_LEAN_AND_MEAN -DNOMINMAX -shared -static -s \
    -o TextTextures.dll TextTextures/TextTextures.cpp TextTextures/TextRender.cpp TextTextures/Text3D.cpp \
    common/Platform.cpp common/Png.cpp common/GdtWriter.cpp common/XModel.cpp common/Radiant.cpp common/MapEdit.cpp \
    -lgdi32 -lcomdlg32 -lshell32 -lole32 -luser32
  ```

Install by copying `TextTextures.dll` and `TextTextures/TextTextures.ini` to `<Black Ops III>\bin\plugins\TextTextures\`.

## Tests

`cmake -S . -B build -DMTPLUGINS_TESTS=ON && cmake --build build && cd build && ctest` runs the logic and 3D text tests
on any platform. `TextTextures/Tests/MockHost.cpp` loads the DLL through a fake host on Windows or Wine.
